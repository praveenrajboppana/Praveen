using System;
using System.Collections.Generic;

class MatrixIslandsWithDiagonals
{
    static readonly int[] dx = { -1, -1, -1, 0, 0, 1, 1, 1 };
    static readonly int[] dy = { -1, 0, 1, -1, 1, -1, 0, 1 };

    static void DFS(int[,] grid, bool[,] visited, int x, int y, int rows, int cols)
    {
        visited[x, y] = true;

        for (int d = 0; d < 8; d++)
        {
            int nx = x + dx[d];
            int ny = y + dy[d];

            if (nx >= 0 && ny >= 0 && nx < rows && ny < cols &&
                grid[nx, ny] == 1 && !visited[nx, ny])
            {
                DFS(grid, visited, nx, ny, rows, cols);
            }
        }
    }

    static int CountIslands(int[,] grid, int rows, int cols)
    {
        bool[,] visited = new bool[rows, cols];
        int count = 0;

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (grid[i, j] == 1 && !visited[i, j])
                {
                    count++;
                    DFS(grid, visited, i, j, rows, cols);
                }
            }
        }

        return count;
    }

    public static void Main()
    {
        Console.Write("Enter number of rows: ");
        int rows = int.Parse(Console.ReadLine());

        Console.Write("Enter number of columns: ");
        int cols = int.Parse(Console.ReadLine());

        int[,] grid = new int[rows, cols];
        Console.WriteLine("Enter the grid:");

        for (int i = 0; i < rows; i++)
        {
            string[] parts;
            while (true)
            {
                Console.Write($"Row {i + 1}: ");
                parts = Console.ReadLine().Trim().Split();
                if (parts.Length == cols) break;
                Console.WriteLine("Please enter the correct number of columns.");
            }

            for (int j = 0; j < cols; j++)
            {
                grid[i, j] = int.Parse(parts[j]);
            }
        }

        int islandCount = CountIslands(grid, rows, cols);
        Console.WriteLine($"\n Total number of islands: {islandCount}");
    }
}
