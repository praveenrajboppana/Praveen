using System;
using System.Collections.Generic;

class KnightsAndPortals
{
    static readonly int[] dx = { -1, 1, 0, 0 };
    static readonly int[] dy = { 0, 0, -1, 1 };

    public static int FindShortestPath(int[,] grid, int rows, int cols)
    {
        var dist = new int[rows, cols, 2];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                dist[i, j, 0] = dist[i, j, 1] = int.MaxValue;

        var queue = new Queue<(int x, int y, int teleportUsed)>();

        if (grid[0, 0] == 0 || grid[rows - 1, cols - 1] == 0)
            return -1;
        dist[0, 0, 0] = 0;
        queue.Enqueue((0, 0, 0));

        List<(int, int)> visitedWithoutTeleport = new();

        while (queue.Count > 0)
        {
            var (x, y, used) = queue.Dequeue();
            int d = dist[x, y, used];

            if (used == 0)
                visitedWithoutTeleport.Add((x, y));

            for (int dir = 0; dir < 4; dir++)
            {
                int nx = x + dx[dir];
                int ny = y + dy[dir];

                if (nx >= 0 && ny >= 0 && nx < rows && ny < cols && grid[nx, ny] == 1)
                {
                    if (dist[nx, ny, used] > d + 1)
                    {
                        dist[nx, ny, used] = d + 1;
                        queue.Enqueue((nx, ny, used));
                    }
                }
            }
        }
        int minWithTeleport = int.MaxValue;
        foreach (var (x1, y1) in visitedWithoutTeleport)
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if ((i != x1 || j != y1) && grid[i, j] == 1)
                    {
                        int total = dist[x1, y1, 0] + 1;
                        if (dist[i, j, 1] > total)
                        {
                            dist[i, j, 1] = total;
                            queue.Enqueue((i, j, 1));
                        }
                    }
                }
            }
        }
        while (queue.Count > 0)
        {
            var (x, y, used) = queue.Dequeue();
            int d = dist[x, y, used];

            for (int dir = 0; dir < 4; dir++)
            {
                int nx = x + dx[dir];
                int ny = y + dy[dir];

                if (nx >= 0 && ny >= 0 && nx < rows && ny < cols && grid[nx, ny] == 1)
                {
                    if (dist[nx, ny, used] > d + 1)
                    {
                        dist[nx, ny, used] = d + 1;
                        queue.Enqueue((nx, ny, used));
                    }
                }
            }
        }

        return Math.Min(dist[rows - 1, cols - 1, 0], dist[rows - 1, cols - 1, 1]) == int.MaxValue
            ? -1
            : Math.Min(dist[rows - 1, cols - 1, 0], dist[rows - 1, cols - 1, 1]);
    }

    public static void Main()
    {
        Console.Write("Enter number of rows: ");
        int rows = int.Parse(Console.ReadLine());
        Console.Write("Enter number of columns: ");
        int cols = int.Parse(Console.ReadLine());

        int[,] grid = new int[rows, cols];

        Console.WriteLine("Enter the grid:");
        for (int i = 0; i < rows; i++)
        {
            string[] parts;
            while (true)
            {
                Console.Write($"Row {i + 1}: ");
                parts = Console.ReadLine().Trim().Split();
                if (parts.Length == cols) break;
                Console.WriteLine("Incorrect number of columns.Try again.");
            }

            for (int j = 0; j < cols; j++)
            {
                grid[i, j] = int.Parse(parts[j]);
            }
        }

        int result = FindShortestPath(grid, rows, cols);
        Console.WriteLine(result == -1
            ? "\n No path exists even with teleport."
            : $"\n Sortest path length (with one teleport allowed): {result}");
    }
}
