using System;
using System.Collections.Generic;

class SudokuValidator
{
    const int Size = 9;

    public static bool IsValidSudoku(int[,] board, List<List<(int, int)>> customZones)
    {
        return AreRowsValid(board) && AreColumnsValid(board) && AreSubgridsValid(board) && AreCustomZonesValid(board, customZones);
    }

    static bool AreRowsValid(int[,] board)
    {
        for (int i = 0; i < Size; i++)
        {
            HashSet<int> seen = new HashSet<int>();
            for (int j = 0; j < Size; j++)
            {
                if (!IsValidCell(board[i, j], seen)) return false;
            }
        }
        return true;
    }

    static bool AreColumnsValid(int[,] board)
    {
        for (int j = 0; j < Size; j++)
        {
            HashSet<int> seen = new HashSet<int>();
            for (int i = 0; i < Size; i++)
            {
                if (!IsValidCell(board[i, j], seen)) return false;
            }
        }
        return true;
    }

    static bool AreSubgridsValid(int[,] board)
    {
        for (int boxRow = 0; boxRow < Size; boxRow += 3)
        {
            for (int boxCol = 0; boxCol < Size; boxCol += 3)
            {
                HashSet<int> seen = new HashSet<int>();
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int row = boxRow + i;
                        int col = boxCol + j;
                        if (!IsValidCell(board[row, col], seen)) return false;
                    }
                }
            }
        }
        return true;
    }

    static bool AreCustomZonesValid(int[,] board, List<List<(int, int)>> customZones)
    {
        foreach (var zone in customZones)
        {
            if (zone.Count != 9) return false;
            HashSet<int> seen = new HashSet<int>();
            foreach (var (row, col) in zone)
            {
                if (!IsValidCell(board[row, col], seen)) return false;
            }
        }
        return true;
    }

    static bool IsValidCell(int value, HashSet<int> seen)
    {
        if (value < 1 || value > 9 || seen.Contains(value))
            return false;
        seen.Add(value);
        return true;
    }

    public static void Main()
    {
        int[,] board = new int[9, 9];
        Console.WriteLine("Enter the Sudoku board row by row 9 digits separated by Space:");

        for (int i = 0; i < Size; i++)
        {
            while (true)
            {
                Console.Write($"Row {i + 1}: ");
                string input = Console.ReadLine();
                var parts = input.Trim().Split();
                if (parts.Length == 9)
                {
                    try
                    {
                        for (int j = 0; j < 9; j++)
                        {
                            board[i, j] = int.Parse(parts[j]);
                        }
                        break;
                    }
                    catch
                    {
                        Console.WriteLine("Invalid input. Please enter integers only.");
                    }
                }
                else
                {
                    Console.WriteLine("Please enter exactly 9 numbers separated by Space.");
                }
            }
        }

        Console.Write("\nEnter number of custom zones: ");
        int zoneCount = int.Parse(Console.ReadLine());

        List<List<(int, int)>> customZones = new List<List<(int, int)>>();

        for (int z = 0; z < zoneCount; z++)
        {
            Console.WriteLine($"\nEnter 9 cell coordinates for custom zone {z + 1} (format: row col), rows/cols from 0 to 8:");
            List<(int, int)> zone = new List<(int, int)>();

            while (zone.Count < 9)
            {
                Console.Write($"Cell {zone.Count + 1}: ");
                var parts = Console.ReadLine().Trim().Split();
                if (parts.Length == 2 &&
                    int.TryParse(parts[0], out int r) &&
                    int.TryParse(parts[1], out int c) &&
                    r >= 0 && r < 9 && c >= 0 && c < 9)
                {
                    zone.Add((r, c));
                }
                else
                {
                    Console.WriteLine("Invalid input. Enter two integers between 0 and 8.");
                }
            }

            customZones.Add(zone);
        }

        bool isValid = IsValidSudoku(board, customZones);
        Console.WriteLine("\nSudoku is " + (isValid ?"Valid": "InValid"));
    }
}
