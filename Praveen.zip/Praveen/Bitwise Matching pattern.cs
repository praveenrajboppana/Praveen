using System;
class BitwiseMatchingPattern
{
    public static int CountOnes(int num)
    {
        int count = 0;
        while (num > 0)
        {
            count += (num & 1);
            num >>= 1;
        }
        return count;
    }
    public static int NextHigherWithSameOnes(int n)
    {
        int ones = CountOnes(n);
        int candidate = n + 1;

        while (CountOnes(candidate) != ones)
        {
            candidate++;
        }

        return candidate;
    }

    public static void Main()
    {
        Console.Write("Enter a positive integer: ");
        if (int.TryParse(Console.ReadLine(), out int n) && n >= 0)
        {
            int result = NextHigherWithSameOnes(n);
            Console.WriteLine($"\nNext larger number with same number of 1s: {result}");
            Console.WriteLine($"Binary of {n}: {Convert.ToString(n, 2)}");
            Console.WriteLine($"Binary of {result}: {Convert.ToString(result, 2)}");
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter Positive integer.");
        }
    }
}
