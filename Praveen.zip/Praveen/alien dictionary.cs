using System;
using System.Collections.Generic;
using System.Linq;

class AlienDictionary
{
    public static string AlienOrder(string[] words)
    {
        Dictionary<char, HashSet<char>> graph = new Dictionary<char, HashSet<char>>();
        Dictionary<char, int> inDegree = new Dictionary<char, int>();
        foreach (string word in words)
        {
            foreach (char c in word)
            {
                if (!graph.ContainsKey(c))
                {
                    graph[c] = new HashSet<char>();
                    inDegree[c] = 0;
                }
            }
        }
        for (int i = 0; i < words.Length - 1; i++)
        {
            string w1 = words[i];
            string w2 = words[i + 1];
            int minLength = Math.Min(w1.Length, w2.Length);
            bool foundDifference = false;
            for (int j = 0; j < minLength; j++)
            {
                char c1 = w1[j];
                char c2 = w2[j];

                if (c1 != c2)
                {
                    if (!graph[c1].Contains(c2))
                    {
                        graph[c1].Add(c2);
                        inDegree[c2]++;
                    }
                    foundDifference = true;
                    break;
                }
            }
            if (!foundDifference && w1.Length > w2.Length)
                return "";
        }
        Queue<char> queue = new Queue<char>();
        foreach (var c in inDegree.Keys)
        {
            if (inDegree[c] == 0)
                queue.Enqueue(c);
        }

        List<char> result = new List<char>();
        while (queue.Count > 0)
        {
            char curr = queue.Dequeue();
            result.Add(curr);

            foreach (char neighbor in graph[curr])
            {
                inDegree[neighbor]--;
                if (inDegree[neighbor] == 0)
                    queue.Enqueue(neighbor);
            }
        }

        return result.Count == inDegree.Count ? new string(result.ToArray()) : "";
    }

    public static void Main()
    {
        Console.Write("Enter number of words: ");
        if (!int.TryParse(Console.ReadLine(), out int n) || n <= 0)
        {
            Console.WriteLine("Invalid number.");
            return;
        }

        string[] words = new string[n];
        Console.WriteLine("Enter the words one by one:");

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Word {i + 1}: ");
            words[i] = Console.ReadLine().Trim();
        }

        string order = AlienOrder(words);
        Console.WriteLine(string.IsNullOrEmpty(order)
            ? "\n invalid alien dictionary ordering"
            : $"\n alien Dictionary Character Order: {order}");
    }
}
